package edu.dcccd.populationdb;

public record CityPopulation(String cityName, long population) {
}
