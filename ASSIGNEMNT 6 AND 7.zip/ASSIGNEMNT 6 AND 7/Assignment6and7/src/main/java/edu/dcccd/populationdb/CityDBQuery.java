package edu.dcccd.populationdb;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/*
 This class executes queries on the CityDB database, stores the data in an ArrayList.

 ***********************************
 ***    DO NOT CHANGE THIS CLASS ***
 ***********************************
*/

public class CityDBQuery {

    public final String DB_URL = "jdbc:derby:CityDB"; // Database URL Constant

    private final List<CityPopulation> tableData;  // Store data

    /**
     * Constructor
     */
    public CityDBQuery( String query ) {   // Query passed to this constructor: "SELECT * FROM City"
        tableData = new ArrayList<>();     // Create an ArrayList for the table data.
        // Get a connection to the database.
        // This method loads the JDBC and gets a connection to the database.

        try {
            // Database connection
            Connection conn = DriverManager.getConnection(DB_URL);    // Create a connection to the database.
            Statement stmt = conn.createStatement(     // Create a Statement object for the query.
                ResultSet.TYPE_SCROLL_INSENSITIVE,
                ResultSet.CONCUR_READ_ONLY);

            ResultSet resultSet = stmt.executeQuery(query);    // Execute the query.
            while (resultSet.next()) {          // Store the columns in the tableData ArrayList
                tableData.add(new CityPopulation(resultSet.getString(1),
                    ( long ) Double.parseDouble(resultSet.getString(2))));
            }

            stmt.close();      // Close the statement and connection objects.
            conn.close();
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
            ex.printStackTrace();
            System.exit(9);
        }
    }

    public List<CityPopulation> getTableData() {
        return tableData;
    } // Returns the table data as a List.

}
