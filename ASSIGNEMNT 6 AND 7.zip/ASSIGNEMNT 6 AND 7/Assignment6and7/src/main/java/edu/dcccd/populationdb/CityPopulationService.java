package edu.dcccd.populationdb;

import java.util.Comparator;
import java.util.List;

/*
 This class executes queries on the CityDB database, stores the data in an ArrayList, and can sort the List in different sequences;

 ***********************************
 ***    DO NOT CHANGE THIS CLASS ***
 ***********************************
*/

public class CityPopulationService {
    public enum SEQUENCE { ASC, DSC, NAME }
    public enum STATISTIC { TOTAL, AVERAGE, HIGHEST, LOWEST }
    private String table;
    private final List<CityPopulation> tableData;

    public CityPopulationService() {
        CityDBQuery cityDBQuery = new CityDBQuery("SELECT * FROM City");
        tableData = cityDBQuery.getTableData();
        updateTable();
    }

    public String getTable(SEQUENCE seq) {
        switch (seq) {
            case ASC -> sortAscending();
            case DSC -> sortDescending();
            case NAME -> sortByName();
        }
        updateTable();
        return table;
    }

    public int getTableLen() {
        return tableData.size();
    }

    private void updateTable() {
        StringBuilder sb = new StringBuilder();
        tableData.forEach(cp ->
                sb.append(String.format("%-40s",cp.cityName()))
                        .append(String.format("%,10d\n", cp.population())));
        table = sb.toString();
    }

    void sortAscending() {
        tableData.sort(Comparator.comparingLong(CityPopulation ::population));
    }
    void sortDescending() {
        tableData.sort(Comparator.comparingLong(CityPopulation ::population).reversed());
    }
    void sortByName() {
        tableData.sort(Comparator.comparing(CityPopulation ::cityName));
    }

    // The following methods are used to sort the data table or calculate amounts for the buttons.  Return the List after a sort.

    private long getPopulationTotal() {
        return tableData.stream().mapToLong(CityPopulation ::population).sum();
    }

    private long getPopulationAverage() {
        return getPopulationTotal() / tableData.size();
    }

    private long getHighestPopulation() {
        return tableData.stream().mapToLong(CityPopulation ::population).reduce(Long :: max).orElse(0L);
    }

    private long getLowestPopulation() {
        return tableData.stream().mapToLong(CityPopulation ::population).reduce(Long :: min).orElse(0L);
    }

    String getLabel(STATISTIC stat) {
        return List.of("Total:", "Average:", "Highest:", "Lowest:").get(stat.ordinal());
    }

    String getStat(STATISTIC stat) {
        return switch(stat) {
            case TOTAL   -> String.format("%,10d", getPopulationTotal());
            case AVERAGE -> String.format("%,10d", getPopulationAverage());
            case HIGHEST -> String.format("%,10d", getHighestPopulation());
            case LOWEST  -> String.format("%,10d", getLowestPopulation());
        };
    }
}
